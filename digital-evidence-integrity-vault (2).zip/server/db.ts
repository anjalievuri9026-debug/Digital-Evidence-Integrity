import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { GENESIS_HASH, hashPassword, calculateEntryHash, canonicalize, sha256 } from './crypto.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'deiv.db');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export const db = new DatabaseSync(DB_FILE);

// Enable WAL mode for high concurrent read/write throughput and ACID reliability
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA synchronous = NORMAL;');

export interface UserRow {
  id: string;
  username: string;
  email: string;
  full_name: string;
  role: 'Administrator' | 'Investigator' | 'Auditor';
  password_hash: string;
  password_salt: string;
  is_active: number;
  created_at: string;
  updated_at: string;
}

export interface SessionRow {
  token: string;
  user_id: string;
  expires_at: string;
  created_at: string;
}

export interface EvidenceRow {
  id: string;
  case_id: string;
  title: string;
  original_filename: string;
  storage_filename: string;
  mime_type: string;
  file_size_bytes: number;
  original_sha256: string;
  uploader_id: string;
  uploader_name: string;
  uploader_role: string;
  created_at: string;
  status: 'VERIFIED' | 'TAMPER_DETECTED' | 'UNVERIFIED' | 'MISSING_FILE' | 'VERIFICATION_FAILED';
  last_verified_at: string | null;
  last_calculated_sha256: string | null;
  notes: string;
  tags: string;
  is_tampered_demo: number;
}

export interface CustodyEventRow {
  id: string;
  evidence_id: string;
  action: string;
  actor_id: string;
  actor_name: string;
  actor_role: string;
  timestamp_utc: string;
  details_json: string;
  created_at: string;
}

export interface AuditLogRow {
  id: number;
  event_id: string;
  sequence_num: number;
  actor_id: string;
  actor_name: string;
  actor_role: string;
  action: string;
  evidence_id: string | null;
  timestamp_utc: string;
  details_canonical: string;
  prev_entry_hash: string;
  current_entry_hash: string;
}

// Initialize tables and indexes
export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('Administrator', 'Investigator', 'Auditor')),
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS evidence (
      id TEXT PRIMARY KEY,
      case_id TEXT NOT NULL,
      title TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      storage_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size_bytes INTEGER NOT NULL,
      original_sha256 TEXT NOT NULL,
      uploader_id TEXT NOT NULL REFERENCES users(id),
      uploader_name TEXT NOT NULL,
      uploader_role TEXT NOT NULL,
      created_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'UNVERIFIED' CHECK(status IN ('VERIFIED', 'TAMPER_DETECTED', 'UNVERIFIED', 'MISSING_FILE', 'VERIFICATION_FAILED')),
      last_verified_at TEXT,
      last_calculated_sha256 TEXT,
      notes TEXT DEFAULT '',
      tags TEXT DEFAULT '',
      is_tampered_demo INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_evidence_case ON evidence(case_id);
    CREATE INDEX IF NOT EXISTS idx_evidence_sha256 ON evidence(original_sha256);
    CREATE INDEX IF NOT EXISTS idx_evidence_status ON evidence(status);

    CREATE TABLE IF NOT EXISTS custody_events (
      id TEXT PRIMARY KEY,
      evidence_id TEXT NOT NULL REFERENCES evidence(id) ON DELETE CASCADE,
      action TEXT NOT NULL,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      timestamp_utc TEXT NOT NULL,
      details_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_custody_evidence ON custody_events(evidence_id);

    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_id TEXT UNIQUE NOT NULL,
      sequence_num INTEGER NOT NULL,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      evidence_id TEXT,
      timestamp_utc TEXT NOT NULL,
      details_canonical TEXT NOT NULL,
      prev_entry_hash TEXT NOT NULL,
      current_entry_hash TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_audit_seq ON audit_log(sequence_num);
    CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
  `);

  seedDefaultUsers();
}

function seedDefaultUsers() {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM users');
  const result = countStmt.get() as { count: number };
  if (result.count === 0) {
    const now = new Date().toISOString();

    const adminAuth = hashPassword('Admin@DEIV2026!');
    const investigatorAuth = hashPassword('Investigator@DEIV2026!');
    const auditorAuth = hashPassword('Auditor@DEIV2026!');

    const insert = db.prepare(`
      INSERT INTO users (id, username, email, full_name, role, password_hash, password_salt, is_active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);

    insert.run('usr-admin-01', 'admin', 'admin@deiv.local', 'Chief Security Officer', 'Administrator', adminAuth.hash, adminAuth.salt, now, now);
    insert.run('usr-inv-01', 'investigator', 'investigator@deiv.local', 'Detective Sarah Chen', 'Investigator', investigatorAuth.hash, investigatorAuth.salt, now, now);
    insert.run('usr-aud-01', 'auditor', 'auditor@deiv.local', 'Inspector Marcus Vance', 'Auditor', auditorAuth.hash, auditorAuth.salt, now, now);

    // Initial Genesis Audit Event
    appendAuditLog({
      actorId: 'usr-admin-01',
      actorName: 'Chief Security Officer',
      actorRole: 'Administrator',
      action: 'SYSTEM_GENESIS_INITIALIZATION',
      evidenceId: null,
      details: {
        message: 'Digital Evidence Integrity Vault initialized with cryptographic root',
        version: '1.0.0-forensic',
        system_actor: 'SYSTEM_BOOT',
      },
    });
  }
}

/**
 * Appends a tamper-evident audit log entry linked to the previous entry hash.
 */
export function appendAuditLog(params: {
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  evidenceId: string | null;
  details: unknown;
  timestampUtc?: string;
}): AuditLogRow {
  const timestampUtc = params.timestampUtc || new Date().toISOString();
  const eventId = `EVT-${crypto.randomUUID()}`;

  // Get last entry to fetch sequence_num and prev_entry_hash
  const lastEntryStmt = db.prepare('SELECT sequence_num, current_entry_hash FROM audit_log ORDER BY id DESC LIMIT 1');
  const lastEntry = lastEntryStmt.get() as { sequence_num: number; current_entry_hash: string } | undefined;

  const sequenceNum = lastEntry ? lastEntry.sequence_num + 1 : 1;
  const prevEntryHash = lastEntry ? lastEntry.current_entry_hash : GENESIS_HASH;

  const canonicalDetails = canonicalize(params.details);
  const currentEntryHash = calculateEntryHash(
    prevEntryHash,
    eventId,
    params.action,
    params.actorId,
    timestampUtc,
    params.details
  );

  const insert = db.prepare(`
    INSERT INTO audit_log (
      event_id, sequence_num, actor_id, actor_name, actor_role, action,
      evidence_id, timestamp_utc, details_canonical, prev_entry_hash, current_entry_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insert.run(
    eventId,
    sequenceNum,
    params.actorId,
    params.actorName,
    params.actorRole,
    params.action,
    params.evidenceId,
    timestampUtc,
    canonicalDetails,
    prevEntryHash,
    currentEntryHash
  );

  const getStmt = db.prepare('SELECT * FROM audit_log WHERE event_id = ?');
  return getStmt.get(eventId) as unknown as AuditLogRow;
}

export interface ChainVerificationResult {
  isValid: boolean;
  totalEntries: number;
  genesisHash: string;
  tipHash: string | null;
  verifiedCount: number;
  brokenAtSequence?: number;
  brokenEventId?: string;
  reason?: string;
  discrepancyType?: 'HASH_MISMATCH' | 'PREV_HASH_LINK_BROKEN' | 'SEQUENCE_GAP' | 'GENESIS_TAMPER';
  educationalExplanation: string;
}

/**
 * Validates the entire cryptographic chain from Genesis to tip.
 * Checks:
 * 1. Genesis entry links to standard 0000...0000
 * 2. Strict sequential order (seq = 1, 2, 3...)
 * 3. Each entry's prev_entry_hash matches the previous record's current_entry_hash
 * 4. Each entry's current_entry_hash matches SHA256(prev_hash | eventId | action | actorId | timestamp | canonicalDetails)
 */
export function verifyAuditChain(): ChainVerificationResult {
  const stmt = db.prepare('SELECT * FROM audit_log ORDER BY sequence_num ASC');
  const rows = stmt.all() as unknown as AuditLogRow[];

  const explanation =
    'Cryptographic hash chaining ensures that any retroactive modification, deletion, or insertion of audit entries immediately breaks the subsequent hash links. However, a local hash chain is tamper-evident, not absolutely immutable: an attacker with raw, unconstrained write access to the host storage could mathematically re-compute the entire chain from the point of tampering onwards. Defense-in-depth requires restricted database privileges, independent off-site replication, and external timestamping anchors.';

  if (rows.length === 0) {
    return {
      isValid: true,
      totalEntries: 0,
      genesisHash: GENESIS_HASH,
      tipHash: null,
      verifiedCount: 0,
      educationalExplanation: explanation,
    };
  }

  let expectedPrevHash = GENESIS_HASH;

  for (let i = 0; i < rows.length; i++) {
    const entry = rows[i];
    const expectedSeq = i + 1;

    // Check sequence continuity
    if (entry.sequence_num !== expectedSeq) {
      return {
        isValid: false,
        totalEntries: rows.length,
        genesisHash: GENESIS_HASH,
        tipHash: rows[rows.length - 1].current_entry_hash,
        verifiedCount: i,
        brokenAtSequence: entry.sequence_num,
        brokenEventId: entry.event_id,
        reason: `Sequence break detected: expected sequence #${expectedSeq}, encountered #${entry.sequence_num}`,
        discrepancyType: 'SEQUENCE_GAP',
        educationalExplanation: explanation,
      };
    }

    // Check link to previous hash
    if (entry.prev_entry_hash !== expectedPrevHash) {
      return {
        isValid: false,
        totalEntries: rows.length,
        genesisHash: GENESIS_HASH,
        tipHash: rows[rows.length - 1].current_entry_hash,
        verifiedCount: i,
        brokenAtSequence: entry.sequence_num,
        brokenEventId: entry.event_id,
        reason: `Broken chain link: entry #${entry.sequence_num} links to ${entry.prev_entry_hash.slice(0, 16)}..., but previous entry hash was ${expectedPrevHash.slice(0, 16)}...`,
        discrepancyType: 'PREV_HASH_LINK_BROKEN',
        educationalExplanation: explanation,
      };
    }

    // Re-calculate hash directly from canonical record components
    const recalculatedHash = sha256(
      `${entry.prev_entry_hash}|${entry.event_id}|${entry.action}|${entry.actor_id}|${entry.timestamp_utc}|${entry.details_canonical}`
    );

    if (recalculatedHash !== entry.current_entry_hash) {
      return {
        isValid: false,
        totalEntries: rows.length,
        genesisHash: GENESIS_HASH,
        tipHash: rows[rows.length - 1].current_entry_hash,
        verifiedCount: i,
        brokenAtSequence: entry.sequence_num,
        brokenEventId: entry.event_id,
        reason: `Hash discrepancy detected in entry #${entry.sequence_num}: stored hash is ${entry.current_entry_hash.slice(0, 16)}..., but canonical recalculation produced ${recalculatedHash.slice(0, 16)}... Data has been altered!`,
        discrepancyType: 'HASH_MISMATCH',
        educationalExplanation: explanation,
      };
    }

    expectedPrevHash = entry.current_entry_hash;
  }

  return {
    isValid: true,
    totalEntries: rows.length,
    genesisHash: GENESIS_HASH,
    tipHash: rows[rows.length - 1].current_entry_hash,
    verifiedCount: rows.length,
    educationalExplanation: explanation,
  };
}
