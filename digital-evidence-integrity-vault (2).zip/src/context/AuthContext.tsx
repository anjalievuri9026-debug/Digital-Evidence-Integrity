import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { User, UserRole } from '../types';
import { Clock, ShieldAlert, RefreshCw, LogOut, CheckCircle2 } from 'lucide-react';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  sessionExpiresAt: string | null;
  isApproachingExpiry: boolean;
  remainingSeconds: number | null;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  hasRole: (...roles: UserRole[]) => boolean;
  refreshUser: () => Promise<void>;
  extendSession: () => Promise<boolean>;
  simulateExpiryWarning: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Warning threshold: warn when session has <= 5 minutes remaining
const WARNING_THRESHOLD_SECONDS = 5 * 60;

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => {
    return sessionStorage.getItem('deiv_token');
  });
  const [sessionExpiresAt, setSessionExpiresAt] = useState<string | null>(() => {
    return sessionStorage.getItem('deiv_expires_at');
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [remainingSeconds, setRemainingSeconds] = useState<number | null>(null);
  const [isApproachingExpiry, setIsApproachingExpiry] = useState<boolean>(false);
  const [isExtending, setIsExtending] = useState<boolean>(false);
  const [extendNotification, setExtendNotification] = useState<string | null>(null);

  const logout = useCallback(async () => {
    try {
      const currentToken = token || sessionStorage.getItem('deiv_token');
      if (currentToken) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${currentToken}` },
        });
      }
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      sessionStorage.removeItem('deiv_token');
      sessionStorage.removeItem('deiv_expires_at');
      setToken(null);
      setSessionExpiresAt(null);
      setUser(null);
      setIsApproachingExpiry(false);
      setRemainingSeconds(null);
    }
  }, [token]);

  const refreshUser = useCallback(async () => {
    const currentToken = token || sessionStorage.getItem('deiv_token');
    if (!currentToken) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${currentToken}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        if (data.expiresAt) {
          setSessionExpiresAt(data.expiresAt);
          sessionStorage.setItem('deiv_expires_at', data.expiresAt);
        }
      } else {
        // Session invalid or expired
        logout();
      }
    } catch (err) {
      console.error('Failed to fetch user session:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token, logout]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Authentication failed' };
      }

      sessionStorage.setItem('deiv_token', data.token);
      if (data.expiresAt) {
        sessionStorage.setItem('deiv_expires_at', data.expiresAt);
        setSessionExpiresAt(data.expiresAt);
      }
      setToken(data.token);
      setUser(data.user);
      setIsApproachingExpiry(false);
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: 'Network or server error: ' + (err instanceof Error ? err.message : String(err)) };
    }
  };

  const extendSession = async (): Promise<boolean> => {
    const currentToken = token || sessionStorage.getItem('deiv_token');
    if (!currentToken) return false;

    try {
      setIsExtending(true);
      const res = await fetch('/api/auth/extend-session', {
        method: 'POST',
        headers: { Authorization: `Bearer ${currentToken}` },
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to extend session');

      if (data.expiresAt) {
        setSessionExpiresAt(data.expiresAt);
        sessionStorage.setItem('deiv_expires_at', data.expiresAt);
      }

      setIsApproachingExpiry(false);
      setRemainingSeconds(null);
      setExtendNotification('Session successfully renewed for an additional 24 hours.');
      setTimeout(() => setExtendNotification(null), 3000);
      return true;
    } catch (err) {
      console.error('Failed to extend session:', err);
      return false;
    } finally {
      setIsExtending(false);
    }
  };

  // Educational testing utility for college project grading: simulate approaching expiry in 60s
  const simulateExpiryWarning = () => {
    const fakeExpiresAt = new Date(Date.now() + 60 * 1000).toISOString();
    setSessionExpiresAt(fakeExpiresAt);
    setRemainingSeconds(60);
    setIsApproachingExpiry(true);
  };

  // Session countdown and auto-logout checker
  useEffect(() => {
    if (!user || !sessionExpiresAt) {
      setIsApproachingExpiry(false);
      setRemainingSeconds(null);
      return;
    }

    const checkExpiry = () => {
      const now = Date.now();
      const expiresTime = new Date(sessionExpiresAt).getTime();
      const diffSec = Math.floor((expiresTime - now) / 1000);

      if (diffSec <= 0) {
        // Session fully expired
        setRemainingSeconds(0);
        setIsApproachingExpiry(false);
        logout();
      } else if (diffSec <= WARNING_THRESHOLD_SECONDS) {
        // Approaching expiry
        setRemainingSeconds(diffSec);
        setIsApproachingExpiry(true);
      } else {
        setRemainingSeconds(diffSec);
        setIsApproachingExpiry(false);
      }
    };

    checkExpiry();
    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [user, sessionExpiresAt, logout]);

  const hasRole = (...roles: UserRole[]): boolean => {
    if (!user) return false;
    return roles.includes(user.role);
  };

  const formatCountdown = (seconds: number | null): string => {
    if (seconds === null || seconds < 0) return '00:00';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        sessionExpiresAt,
        isApproachingExpiry,
        remainingSeconds,
        login,
        logout,
        hasRole,
        refreshUser,
        extendSession,
        simulateExpiryWarning,
      }}
    >
      {children}

      {/* Extension success notification toast */}
      {extendNotification && (
        <div className="fixed bottom-5 right-5 z-50 p-3.5 rounded-xl bg-emerald-950/90 border border-emerald-600 text-emerald-200 text-xs font-semibold shadow-2xl flex items-center gap-2.5 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{extendNotification}</span>
        </div>
      )}

      {/* Auto-Logout Impending Expiry Warning Modal */}
      {isApproachingExpiry && user && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="session-warning-title"
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="bg-[#0b0f19] border-2 border-amber-600/80 rounded-2xl p-6 w-full max-w-md shadow-[0_0_50px_rgba(245,158,11,0.25)] space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="p-2.5 rounded-xl bg-amber-950/80 border border-amber-600/70 text-amber-400 shrink-0">
                <Clock className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 id="session-warning-title" className="text-sm font-bold text-slate-100 font-mono uppercase tracking-wider">
                  Session Expiration Warning
                </h3>
                <p className="text-xs text-amber-300/90 font-medium">
                  Automated Security Timeout Policy
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p className="leading-relaxed">
                Your authenticated forensic session is about to expire due to inactivity or policy timeout. To prevent unauthorized vault access, you will be automatically signed out.
              </p>

              {/* Countdown Display */}
              <div className="p-4 rounded-xl bg-slate-950 border border-amber-900/60 flex flex-col items-center justify-center text-center">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 mb-1">
                  Time Remaining Before Auto-Termination
                </span>
                <span className="text-3xl font-extrabold font-mono text-amber-400 tracking-wider">
                  {formatCountdown(remainingSeconds)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => logout()}
                className="flex-1 py-2.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-red-300 font-semibold text-xs border border-slate-700 transition flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out Now</span>
              </button>

              <button
                type="button"
                onClick={() => extendSession()}
                disabled={isExtending}
                className="flex-1 py-2.5 px-3 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isExtending ? 'animate-spin' : ''}`} />
                <span>{isExtending ? 'Renewing...' : 'Extend Session'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
